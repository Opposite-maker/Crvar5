﻿namespace postgres_sys1
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.labelLoginResult = new System.Windows.Forms.Label();
            this.buttonLogin = new System.Windows.Forms.Button();
            this.textBoxLoginPassword = new System.Windows.Forms.TextBox();
            this.textBoxLoginUsername = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.comboBoxRole = new System.Windows.Forms.ComboBox();
            this.labelRegisterResult = new System.Windows.Forms.Label();
            this.buttonRegister = new System.Windows.Forms.Button();
            this.textBoxRegisterPassword = new System.Windows.Forms.TextBox();
            this.textBoxRegisterUsername = new System.Windows.Forms.TextBox();
            this.buttonStep2 = new System.Windows.Forms.Button();
            this.buttonLogout = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.panelPuzzle = new System.Windows.Forms.Panel();
            this.buttonCheckPuzzle = new System.Windows.Forms.Button();
            this.buttonResetPuzzle = new System.Windows.Forms.Button();
            this.labelPuzzleStatus = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(478, 345);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.labelLoginResult);
            this.tabPage1.Controls.Add(this.buttonLogin);
            this.tabPage1.Controls.Add(this.textBoxLoginPassword);
            this.tabPage1.Controls.Add(this.textBoxLoginUsername);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(470, 316);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Авторизация";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // labelLoginResult
            // 
            this.labelLoginResult.AutoSize = true;
            this.labelLoginResult.Location = new System.Drawing.Point(24, 220);
            this.labelLoginResult.Name = "labelLoginResult";
            this.labelLoginResult.Size = new System.Drawing.Size(135, 16);
            this.labelLoginResult.TabIndex = 3;
            this.labelLoginResult.Text = "Вы не авторизоаны";
            // 
            // buttonLogin
            // 
            this.buttonLogin.Location = new System.Drawing.Point(6, 136);
            this.buttonLogin.Name = "buttonLogin";
            this.buttonLogin.Size = new System.Drawing.Size(151, 23);
            this.buttonLogin.TabIndex = 2;
            this.buttonLogin.Text = "Войти";
            this.buttonLogin.UseVisualStyleBackColor = true;
            this.buttonLogin.Click += new System.EventHandler(this.buttonLogin_Click);
            // 
            // textBoxLoginPassword
            // 
            this.textBoxLoginPassword.Location = new System.Drawing.Point(6, 76);
            this.textBoxLoginPassword.Name = "textBoxLoginPassword";
            this.textBoxLoginPassword.Size = new System.Drawing.Size(151, 22);
            this.textBoxLoginPassword.TabIndex = 1;
            // 
            // textBoxLoginUsername
            // 
            this.textBoxLoginUsername.Location = new System.Drawing.Point(6, 30);
            this.textBoxLoginUsername.Name = "textBoxLoginUsername";
            this.textBoxLoginUsername.Size = new System.Drawing.Size(151, 22);
            this.textBoxLoginUsername.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.comboBoxRole);
            this.tabPage2.Controls.Add(this.labelRegisterResult);
            this.tabPage2.Controls.Add(this.buttonRegister);
            this.tabPage2.Controls.Add(this.textBoxRegisterPassword);
            this.tabPage2.Controls.Add(this.textBoxRegisterUsername);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(470, 316);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Регистрация";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // comboBoxRole
            // 
            this.comboBoxRole.FormattingEnabled = true;
            this.comboBoxRole.Location = new System.Drawing.Point(236, 33);
            this.comboBoxRole.Name = "comboBoxRole";
            this.comboBoxRole.Size = new System.Drawing.Size(147, 24);
            this.comboBoxRole.TabIndex = 4;
            // 
            // labelRegisterResult
            // 
            this.labelRegisterResult.AutoSize = true;
            this.labelRegisterResult.Location = new System.Drawing.Point(13, 235);
            this.labelRegisterResult.Name = "labelRegisterResult";
            this.labelRegisterResult.Size = new System.Drawing.Size(164, 16);
            this.labelRegisterResult.TabIndex = 3;
            this.labelRegisterResult.Text = "Результат регистрации";
            // 
            // buttonRegister
            // 
            this.buttonRegister.Location = new System.Drawing.Point(16, 159);
            this.buttonRegister.Name = "buttonRegister";
            this.buttonRegister.Size = new System.Drawing.Size(181, 23);
            this.buttonRegister.TabIndex = 2;
            this.buttonRegister.Text = "Зарегистрироваться";
            this.buttonRegister.UseVisualStyleBackColor = true;
            this.buttonRegister.Click += new System.EventHandler(this.buttonRegister_Click);
            // 
            // textBoxRegisterPassword
            // 
            this.textBoxRegisterPassword.Location = new System.Drawing.Point(16, 88);
            this.textBoxRegisterPassword.Name = "textBoxRegisterPassword";
            this.textBoxRegisterPassword.Size = new System.Drawing.Size(161, 22);
            this.textBoxRegisterPassword.TabIndex = 1;
            // 
            // textBoxRegisterUsername
            // 
            this.textBoxRegisterUsername.Location = new System.Drawing.Point(16, 33);
            this.textBoxRegisterUsername.Name = "textBoxRegisterUsername";
            this.textBoxRegisterUsername.Size = new System.Drawing.Size(161, 22);
            this.textBoxRegisterUsername.TabIndex = 0;
            // 
            // buttonStep2
            // 
            this.buttonStep2.Location = new System.Drawing.Point(1109, 574);
            this.buttonStep2.Name = "buttonStep2";
            this.buttonStep2.Size = new System.Drawing.Size(136, 23);
            this.buttonStep2.TabIndex = 1;
            this.buttonStep2.Text = "Далее";
            this.buttonStep2.UseVisualStyleBackColor = true;
            this.buttonStep2.Visible = false;
            this.buttonStep2.Click += new System.EventHandler(this.buttonStep2_Click);
            // 
            // buttonLogout
            // 
            this.buttonLogout.Location = new System.Drawing.Point(294, 557);
            this.buttonLogout.Name = "buttonLogout";
            this.buttonLogout.Size = new System.Drawing.Size(215, 23);
            this.buttonLogout.TabIndex = 2;
            this.buttonLogout.Text = "Выйти из системы";
            this.buttonLogout.UseVisualStyleBackColor = true;
            this.buttonLogout.Click += new System.EventHandler(this.buttonLogout_Click);
            // 
            // buttonExit
            // 
            this.buttonExit.Location = new System.Drawing.Point(12, 557);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(195, 23);
            this.buttonExit.TabIndex = 3;
            this.buttonExit.Text = "Закрыть программу";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // panelPuzzle
            // 
            this.panelPuzzle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelPuzzle.Location = new System.Drawing.Point(621, 37);
            this.panelPuzzle.Name = "panelPuzzle";
            this.panelPuzzle.Size = new System.Drawing.Size(450, 400);
            this.panelPuzzle.TabIndex = 4;
            this.panelPuzzle.Visible = false;
            // 
            // buttonCheckPuzzle
            // 
            this.buttonCheckPuzzle.Location = new System.Drawing.Point(645, 507);
            this.buttonCheckPuzzle.Name = "buttonCheckPuzzle";
            this.buttonCheckPuzzle.Size = new System.Drawing.Size(148, 40);
            this.buttonCheckPuzzle.TabIndex = 5;
            this.buttonCheckPuzzle.Text = "Проверить капчу";
            this.buttonCheckPuzzle.UseVisualStyleBackColor = true;
            this.buttonCheckPuzzle.Visible = false;
            this.buttonCheckPuzzle.Click += new System.EventHandler(this.buttonCheckPuzzle_Click_1);
            // 
            // buttonResetPuzzle
            // 
            this.buttonResetPuzzle.Location = new System.Drawing.Point(947, 507);
            this.buttonResetPuzzle.Name = "buttonResetPuzzle";
            this.buttonResetPuzzle.Size = new System.Drawing.Size(124, 40);
            this.buttonResetPuzzle.TabIndex = 6;
            this.buttonResetPuzzle.Text = "Сбросить";
            this.buttonResetPuzzle.UseVisualStyleBackColor = true;
            this.buttonResetPuzzle.Visible = false;
            this.buttonResetPuzzle.Click += new System.EventHandler(this.buttonResetPuzzle_Click_1);
            // 
            // labelPuzzleStatus
            // 
            this.labelPuzzleStatus.AutoSize = true;
            this.labelPuzzleStatus.Location = new System.Drawing.Point(652, 469);
            this.labelPuzzleStatus.Name = "labelPuzzleStatus";
            this.labelPuzzleStatus.Size = new System.Drawing.Size(17, 16);
            this.labelPuzzleStatus.TabIndex = 7;
            this.labelPuzzleStatus.Text = "\"\"";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1272, 638);
            this.Controls.Add(this.labelPuzzleStatus);
            this.Controls.Add(this.buttonResetPuzzle);
            this.Controls.Add(this.buttonCheckPuzzle);
            this.Controls.Add(this.panelPuzzle);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.buttonLogout);
            this.Controls.Add(this.buttonStep2);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label labelLoginResult;
        private System.Windows.Forms.Button buttonLogin;
        private System.Windows.Forms.TextBox textBoxLoginPassword;
        private System.Windows.Forms.TextBox textBoxLoginUsername;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ComboBox comboBoxRole;
        private System.Windows.Forms.Label labelRegisterResult;
        private System.Windows.Forms.Button buttonRegister;
        private System.Windows.Forms.TextBox textBoxRegisterPassword;
        private System.Windows.Forms.TextBox textBoxRegisterUsername;
        private System.Windows.Forms.Button buttonStep2;
        private System.Windows.Forms.Button buttonLogout;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Panel panelPuzzle;
        private System.Windows.Forms.Button buttonCheckPuzzle;
        private System.Windows.Forms.Button buttonResetPuzzle;
        private System.Windows.Forms.Label labelPuzzleStatus;
    }
}

