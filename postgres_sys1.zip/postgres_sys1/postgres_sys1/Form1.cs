﻿using System;
using System.Text;
using System.Windows.Forms;
using Npgsql;

namespace postgres_sys1
{
    public partial class Form1 : Form
    {
        private readonly string _connectionString;
        private readonly DatabaseInitializer _databaseInitializer;
        private PuzzleCaptcha puzzleCaptcha;
        private string currentUsername;
        private string currentPassword;

        public Form1()
        {
            InitializeComponent();

            _connectionString = "Host=fracieheemu.beget.app;Username=cloud_user;Password=p0I78*5FMwyP;Database=default_db";
            _databaseInitializer = new DatabaseInitializer(_connectionString);
            InitializeRolesComboBox();
        }

        private void InitializeRolesComboBox()
        {
            comboBoxRole.Items.AddRange(new string[] { "admin", "moderator", "user" });
            comboBoxRole.SelectedIndex = 0;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                _databaseInitializer.InitializeDatabase();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при инициализации базы данных: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonRegister_Click(object sender, EventArgs e)
        {
            string username = textBoxRegisterUsername.Text;
            string password = textBoxRegisterPassword.Text;
            string role = comboBoxRole.SelectedItem?.ToString();

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password) || string.IsNullOrWhiteSpace(role))
            {
                labelRegisterResult.Text = "Пожалуйста, заполните все поля";
                return;
            }

            try
            {
                using (var connection = new NpgsqlConnection(_connectionString))
                {
                    connection.Open();

                    string checkUserQuery = "SELECT COUNT(*) FROM users WHERE username = @username";
                    using (var checkCommand = new NpgsqlCommand(checkUserQuery, connection))
                    {
                        checkCommand.Parameters.AddWithValue("@username", username);
                        int userCount = Convert.ToInt32(checkCommand.ExecuteScalar());
                        if (userCount > 0)
                        {
                            labelRegisterResult.Text = "Пользователь с таким именем уже существует";
                            return;
                        }
                    }

                    string checkRoleQuery = "SELECT id FROM roles WHERE name = @role";
                    using (var checkRoleCommand = new NpgsqlCommand(checkRoleQuery, connection))
                    {
                        checkRoleCommand.Parameters.AddWithValue("@role", role);
                        object roleIdObj = checkRoleCommand.ExecuteScalar();
                        if (roleIdObj == null)
                        {
                            labelRegisterResult.Text = "Роль не найдена";
                            return;
                        }

                        int roleId = Convert.ToInt32(roleIdObj);

                        string insertUserQuery = @"
                            INSERT INTO users (username, password, role_id, failed_attempts)
                            VALUES (@username, @password, @role_id, 0)";

                        using (var insertCommand = new NpgsqlCommand(insertUserQuery, connection))
                        {
                            insertCommand.Parameters.AddWithValue("@username", username);
                            insertCommand.Parameters.AddWithValue("@password", password);
                            insertCommand.Parameters.AddWithValue("@role_id", roleId);
                            insertCommand.ExecuteNonQuery();
                        }

                        labelRegisterResult.Text = $"Регистрация успешна. Имя: {username}, Пароль: {password}, Роль: {role}";
                    }
                }
            }
            catch (Exception ex)
            {
                labelRegisterResult.Text = $"Ошибка при регистрации: {ex.Message}";
            }
        }

        private string GetTableContents(string tableName)
        {
            StringBuilder result = new StringBuilder();
            result.AppendLine($"Содержимое таблицы {tableName}:");

            using (var connection = new NpgsqlConnection(_connectionString))
            {
                connection.Open();
                using (var command = new NpgsqlCommand($"SELECT * FROM {tableName}", connection))
                {
                    using (var reader = command.ExecuteReader())
                    {
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            result.Append(reader.GetName(i) + "\t");
                        }
                        result.AppendLine();

                        while (reader.Read())
                        {
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                result.Append(reader[i].ToString() + "\t");
                            }
                            result.AppendLine();
                        }
                    }
                }
            }

            return result.ToString();
        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            string usersContent = GetTableContents("users");
            string rolesContent = GetTableContents("roles");
            MessageBox.Show(usersContent + "\n\n" + rolesContent, "Содержимое таблиц", MessageBoxButtons.OK, MessageBoxIcon.Information);

            string username = textBoxLoginUsername.Text;
            string password = textBoxLoginPassword.Text;

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                labelLoginResult.Text = "Пожалуйста, заполните все поля";
                return;
            }

            try
            {
                using (var connection = new NpgsqlConnection(_connectionString))
                {
                    connection.Open();

                    string loginQuery = @"
                        SELECT u.id, r.name as role, u.password, u.failed_attempts
                        FROM users u
                        JOIN roles r ON u.role_id = r.id
                        WHERE u.username = @username";

                    using (var command = new NpgsqlCommand(loginQuery, connection))
                    {
                        command.Parameters.AddWithValue("@username", username);

                        using (var reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                int userId = reader.GetInt32(0);
                                string role = reader.GetString(1);
                                string storedPassword = reader.GetString(2);
                                int failedAttempts = reader.GetInt32(3);

                                // Проверка блокировки
                                if (role == "blocked")
                                {
                                    labelLoginResult.Text = "Вы заблокированы. Обратитесь к администратору";
                                    return;
                                }

                                MessageBox.Show($"Пользователь найден:\nID: {userId}\nРоль: {role}\nСохраненный пароль: {storedPassword}\nНеудачных попыток: {failedAttempts}",
                                    "Отладочная информация", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                if (password == storedPassword)
                                {
                                    // Пароль верный - показываем капчу
                                    currentUsername = username;
                                    currentPassword = password;
                                    ShowPuzzleCaptcha();
                                }
                                else
                                {
                                    labelLoginResult.Text = "Неверный пароль";
                                    IncrementFailedAttempts(username);
                                }
                            }
                            else
                            {
                                labelLoginResult.Text = "Пользователь не найден";
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при входе: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ShowPuzzleCaptcha()
        {
            // Скрываем элементы авторизации
            textBoxLoginUsername.Enabled = false;
            textBoxLoginPassword.Enabled = false;
            buttonLogin.Enabled = false;

            // Показываем капчу
            panelPuzzle.Visible = true;
            buttonCheckPuzzle.Visible = true;
            buttonResetPuzzle.Visible = true;
            labelPuzzleStatus.Text = "Соберите пазл: кликните на два элемента, чтобы поменять их местами";

            // Создаем новый пазл
            if (puzzleCaptcha != null)
            {
                puzzleCaptcha.Dispose();
            }
            puzzleCaptcha = new PuzzleCaptcha(panelPuzzle);
        }

        private void HidePuzzleCaptcha()
        {
            panelPuzzle.Visible = false;
            buttonCheckPuzzle.Visible = false;
            buttonResetPuzzle.Visible = false;
            labelPuzzleStatus.Text = "";

            textBoxLoginUsername.Enabled = true;
            textBoxLoginPassword.Enabled = true;
            buttonLogin.Enabled = true;

            if (puzzleCaptcha != null)
            {
                puzzleCaptcha.Dispose();
                puzzleCaptcha = null;
            }
        }

      
        private void IncrementFailedAttempts(string username)
        {
            try
            {
                using (var connection = new NpgsqlConnection(_connectionString))
                {
                    connection.Open();

                    // Увеличиваем счетчик
                    string updateQuery = "UPDATE users SET failed_attempts = failed_attempts + 1 WHERE username = @username";
                    using (var command = new NpgsqlCommand(updateQuery, connection))
                    {
                        command.Parameters.AddWithValue("@username", username);
                        command.ExecuteNonQuery();
                    }

                    // Проверяем, не достигнут ли лимит
                    string checkQuery = "SELECT failed_attempts FROM users WHERE username = @username";
                    using (var command = new NpgsqlCommand(checkQuery, connection))
                    {
                        command.Parameters.AddWithValue("@username", username);
                        int attempts = Convert.ToInt32(command.ExecuteScalar());

                        if (attempts >= 3)
                        {
                            // Блокируем пользователя
                            BlockUser(username);
                            MessageBox.Show("Превышено количество попыток. Ваша учетная запись заблокирована.",
                                "Блокировка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            HidePuzzleCaptcha();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при обновлении попыток: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ResetFailedAttempts(string username)
        {
            try
            {
                using (var connection = new NpgsqlConnection(_connectionString))
                {
                    connection.Open();
                    string updateQuery = "UPDATE users SET failed_attempts = 0 WHERE username = @username";
                    using (var command = new NpgsqlCommand(updateQuery, connection))
                    {
                        command.Parameters.AddWithValue("@username", username);
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сбросе попыток: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BlockUser(string username)
        {
            try
            {
                using (var connection = new NpgsqlConnection(_connectionString))
                {
                    connection.Open();

                    // Получаем ID роли "blocked"
                    string getRoleIdQuery = "SELECT id FROM roles WHERE name = 'blocked'";
                    int blockedRoleId;
                    using (var command = new NpgsqlCommand(getRoleIdQuery, connection))
                    {
                        blockedRoleId = Convert.ToInt32(command.ExecuteScalar());
                    }

                    // Меняем роль пользователя на "blocked"
                    string updateQuery = "UPDATE users SET role_id = @role_id WHERE username = @username";
                    using (var command = new NpgsqlCommand(updateQuery, connection))
                    {
                        command.Parameters.AddWithValue("@role_id", blockedRoleId);
                        command.Parameters.AddWithValue("@username", username);
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при блокировке пользователя: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private string GetUserRole(string username)
        {
            try
            {
                using (var connection = new NpgsqlConnection(_connectionString))
                {
                    connection.Open();
                    string query = @"
                        SELECT r.name 
                        FROM users u 
                        JOIN roles r ON u.role_id = r.id 
                        WHERE u.username = @username";

                    using (var command = new NpgsqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@username", username);
                        return command.ExecuteScalar()?.ToString() ?? "user";
                    }
                }
            }
            catch
            {
                return "user";
            }
        }

        private void buttonStep2_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.Show();
            this.Hide();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void buttonLogout_Click(object sender, EventArgs e)
        {
            UserSession.ClearSession();
            labelLoginResult.Text = "Вы не авторизованы";
            buttonStep2.Visible = false;
            HidePuzzleCaptcha();
        }

        private void buttonCheckPuzzle_Click_1(object sender, EventArgs e)
        {
            if (puzzleCaptcha.IsSolved())
            {
                // Пазл собран правильно
                labelPuzzleStatus.Text = "Капча пройдена успешно!";

                // Сбрасываем счетчик неудачных попыток
                ResetFailedAttempts(currentUsername);

                // Получаем роль пользователя
                string role = GetUserRole(currentUsername);

                // Авторизуем пользователя
                labelLoginResult.Text = $"Вход выполнен успешно. Роль: {role}";
                UserSession.SetSession(currentUsername, role);
                buttonStep2.Visible = true;

                HidePuzzleCaptcha();
            }
            else
            {
                // Пазл собран неправильно
                labelPuzzleStatus.Text = "Неправильно! Попробуйте еще раз";
                IncrementFailedAttempts(currentUsername);

                // Проверяем, что puzzleCaptcha не был уничтожен после IncrementFailedAttempts
                if (puzzleCaptcha != null)
                {
                    puzzleCaptcha.Reset();
                }
            }
        }

        private void buttonResetPuzzle_Click_1(object sender, EventArgs e)
        {
            puzzleCaptcha.Reset();
            labelPuzzleStatus.Text = "Пазл сброшен. Попробуйте снова";
        }
    }
}