﻿using System;
using System.Data;
using Npgsql;
using System.Windows.Forms;
using postgres_sys1;

namespace postgres_sys1
{
    public partial class Form2 : Form
    {
        private readonly string _connectionString;
        private NpgsqlDataAdapter dataAdapterUsers;
        private NpgsqlDataAdapter dataAdapterRoles;
        private NpgsqlDataAdapter dataAdapterResearcher;
        private NpgsqlDataAdapter dataAdapterSource;
        private NpgsqlDataAdapter dataAdapterResearch;
        private DataSet dataSet;

        public Form2()
        {
            InitializeComponent();
            _connectionString = "Host=fracieheemu.beget.app;Username=cloud_user;Password=p0I78*5FMwyP;Database=default_db";
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            labelUserInfo.Text = $"Имя пользователя: {UserSession.Username}\nРоль: {UserSession.Role}";

            if (UserSession.Role == "admin")
            {
                DataGridViewUsers.Visible = true;
                DataGridViewRoles.Visible = true;

                ButtonAddUsers.Visible = true;
                ButtonDelUsers.Visible = true;
                ButtonSaveUsers.Visible = true;
                ButtonAddRoles.Visible = true;
                ButtonDelRoles.Visible = true;
                ButtonSaveRoles.Visible = true;
                ButtonAddResearcher.Visible = true;
                ButtonDelResearcher.Visible = true;
                ButtonSaveResearcher.Visible = true;
                ButtonAddSource.Visible = true;
                ButtonDelSource.Visible = true;
                ButtonSaveSource.Visible = true;
                ButtonAddResearch.Visible = true;
                ButtonDelResearch.Visible = true;
                ButtonSaveResearch.Visible = true;
            }

            if (UserSession.Role == "moderator")
            {
                DataGridViewUsers.Visible = false;
                DataGridViewRoles.Visible = false;

                ButtonAddUsers.Visible = false;
                ButtonDelUsers.Visible = false;
                ButtonSaveUsers.Visible = false;
                ButtonAddRoles.Visible = false;
                ButtonDelRoles.Visible = false;
                ButtonSaveRoles.Visible = false;
                ButtonAddResearcher.Visible = true;
                ButtonDelResearcher.Visible = true;
                ButtonSaveResearcher.Visible = true;
                ButtonAddSource.Visible = true;
                ButtonDelSource.Visible = true;
                ButtonSaveSource.Visible = true;
                ButtonAddResearch.Visible = true;
                ButtonDelResearch.Visible = true;
                ButtonSaveResearch.Visible = true;
            }

            if (UserSession.Role == "user")
            {
                DataGridViewUsers.Visible = false;
                DataGridViewRoles.Visible = false;

                ButtonAddUsers.Visible = false;
                ButtonDelUsers.Visible = false;
                ButtonSaveUsers.Visible = false;
                ButtonAddRoles.Visible = false;
                ButtonDelRoles.Visible = false;
                ButtonSaveRoles.Visible = false;
                ButtonAddResearcher.Visible = false;
                ButtonDelResearcher.Visible = false;
                ButtonSaveResearcher.Visible = false;
                ButtonAddSource.Visible = false;
                ButtonDelSource.Visible = false;
                ButtonSaveSource.Visible = false;
                ButtonAddResearch.Visible = false;
                ButtonDelResearch.Visible = false;
                ButtonSaveResearch.Visible = false;
            }


            LoadData();
            InitializeEventHandlers();
        }

        private void LoadData()
        {
            using (var connection = new NpgsqlConnection(_connectionString))
            {
                connection.Open();
                dataSet = new DataSet();

                dataAdapterUsers = CreateAndFillAdapter("users", connection);
                dataAdapterRoles = CreateAndFillAdapter("roles", connection);
                dataAdapterResearcher = CreateAndFillAdapter("researcher", connection);
                dataAdapterSource = CreateAndFillAdapter("source", connection);
                dataAdapterResearch = CreateAndFillAdapter("research", connection);

                DataGridViewUsers.DataSource = dataSet.Tables["users"];
                DataGridViewRoles.DataSource = dataSet.Tables["roles"];
                DataGridViewResearcher.DataSource = dataSet.Tables["researcher"];
                DataGridViewSource.DataSource = dataSet.Tables["source"];
                DataGridViewResearch.DataSource = dataSet.Tables["research"];
            }
        }

        private NpgsqlDataAdapter CreateAndFillAdapter(string tableName, NpgsqlConnection connection)
        {
            var adapter = new NpgsqlDataAdapter($"SELECT * FROM {tableName}", connection);
            var commandBuilder = new NpgsqlCommandBuilder(adapter);
            adapter.InsertCommand = commandBuilder.GetInsertCommand();
            adapter.UpdateCommand = commandBuilder.GetUpdateCommand();
            adapter.DeleteCommand = commandBuilder.GetDeleteCommand();
            adapter.Fill(dataSet, tableName);

            // Установка Connection для всех команд в адаптере
            adapter.InsertCommand.Connection = connection;
            adapter.UpdateCommand.Connection = connection;
            adapter.DeleteCommand.Connection = connection;

            return adapter;
        }

        private void InitializeEventHandlers()
        {
            ButtonAddUsers.Click += (s, e) => AddRow(dataSet.Tables["users"]);
            ButtonDelUsers.Click += (s, e) => DeleteRow(DataGridViewUsers, dataSet.Tables["users"]);
            ButtonSaveUsers.Click += (s, e) => SaveChanges(dataAdapterUsers, dataSet.Tables["users"], "users");

            ButtonAddRoles.Click += (s, e) => AddRow(dataSet.Tables["roles"]);
            ButtonDelRoles.Click += (s, e) => DeleteRow(DataGridViewRoles, dataSet.Tables["roles"]);
            ButtonSaveRoles.Click += (s, e) => SaveChanges(dataAdapterRoles, dataSet.Tables["roles"], "roles");

            ButtonAddResearcher.Click += (s, e) => AddRow(dataSet.Tables["researcher"]);
            ButtonDelResearcher.Click += (s, e) => DeleteRow(DataGridViewResearcher, dataSet.Tables["researcher"]);
            ButtonSaveResearcher.Click += (s, e) => SaveChanges(dataAdapterResearcher, dataSet.Tables["researcher"], "researcher");

            ButtonAddSource.Click += (s, e) => AddRow(dataSet.Tables["source"]);
            ButtonDelSource.Click += (s, e) => DeleteRow(DataGridViewSource, dataSet.Tables["source"]);
            ButtonSaveSource.Click += (s, e) => SaveChanges(dataAdapterSource, dataSet.Tables["source"], "source");

            ButtonAddResearch.Click += (s, e) => AddRow(dataSet.Tables["research"]);
            ButtonDelResearch.Click += (s, e) => DeleteRow(DataGridViewResearch, dataSet.Tables["research"]);
            ButtonSaveResearch.Click += (s, e) => SaveChanges(dataAdapterResearch, dataSet.Tables["research"], "research");
        }

        private void AddRow(DataTable table)
        {
            DataRow newRow = table.NewRow();
            table.Rows.Add(newRow);
        }

        private void DeleteRow(DataGridView dataGridView, DataTable table)
        {
            if (dataGridView.SelectedRows.Count > 0)
            {
                foreach (DataGridViewRow row in dataGridView.SelectedRows)
                {
                    int index = row.Index;
                    if (index < table.Rows.Count)
                    {
                        table.Rows[index].Delete();
                    }
                }
            }
        }

        private void SaveChanges(NpgsqlDataAdapter dataAdapter, DataTable table, string tableName)
        {
            try
            {
                using (var connection = new NpgsqlConnection(_connectionString))
                {
                    connection.Open();
                    using (var transaction = connection.BeginTransaction())
                    {
                        try
                        {
                            // Создаем новый NpgsqlDataAdapter с текущим соединением
                            string selectCommand = $"SELECT * FROM {tableName}";
                            using (var newAdapter = new NpgsqlDataAdapter(selectCommand, connection))
                            {
                                using (var commandBuilder = new NpgsqlCommandBuilder(newAdapter))
                                {
                                    newAdapter.UpdateCommand = commandBuilder.GetUpdateCommand();
                                    newAdapter.InsertCommand = commandBuilder.GetInsertCommand();
                                    newAdapter.DeleteCommand = commandBuilder.GetDeleteCommand();

                                    newAdapter.UpdateCommand.Transaction = transaction;
                                    newAdapter.InsertCommand.Transaction = transaction;
                                    newAdapter.DeleteCommand.Transaction = transaction;

                                    int rowsAffected = newAdapter.Update(table);

                                    transaction.Commit();
                                    MessageBox.Show($"Изменения в таблице {tableName} успешно сохранены. Затронуто строк: {rowsAffected}");
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            throw; // Пробрасываем исключение дальше
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении изменений в таблицу {tableName}: {ex.Message}");
            }
        }

        private void buttonLogout_Click(object sender, EventArgs e)
        {
            UserSession.ClearSession();
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}