﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Linq;

namespace postgres_sys1
{
    public class PuzzleCaptcha
    {
        private PictureBox[] puzzlePieces;
        private int[] correctOrder;
        private int[] currentOrder;
        private Panel containerPanel;
        private Image originalImage;
        private int selectedPieceIndex = -1;

        public PuzzleCaptcha(Panel panel)
        {
            containerPanel = panel;
            InitializePuzzle();
        }

        private void InitializePuzzle()
        {
            // Создаем простое изображение 3x3
            originalImage = CreateSimpleImage();

            // Разрезаем на 9 частей
            puzzlePieces = new PictureBox[9];
            correctOrder = new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8 };
            currentOrder = new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8 };

            // Перемешиваем
            ShuffleArray(currentOrder);

            // Создаем PictureBox'ы
            int pieceWidth = 100;
            int pieceHeight = 100;

            for (int i = 0; i < 9; i++)
            {
                puzzlePieces[i] = new PictureBox
                {
                    Width = pieceWidth,
                    Height = pieceHeight,
                    Left = (i % 3) * pieceWidth + 10,
                    Top = (i / 3) * pieceHeight + 10,
                    BorderStyle = BorderStyle.FixedSingle,
                    SizeMode = PictureBoxSizeMode.StretchImage,
                    Tag = i,
                    Cursor = Cursors.Hand
                };

                puzzlePieces[i].Click += PuzzlePiece_Click;
                containerPanel.Controls.Add(puzzlePieces[i]);
            }

            UpdatePuzzleDisplay();
        }

        private Image CreateSimpleImage()
        {
            // Создаем простое цветное изображение 300x300
            Bitmap bmp = new Bitmap(300, 300);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                // Фон
                g.Clear(Color.LightBlue);

                // Рисуем цветные квадраты для каждого фрагмента
                Color[] colors = {
                    Color.Red, Color.Orange, Color.Yellow,
                    Color.Green, Color.Blue, Color.Indigo,
                    Color.Violet, Color.Pink, Color.Brown
                };

                for (int i = 0; i < 9; i++)
                {
                    int x = (i % 3) * 100;
                    int y = (i / 3) * 100;

                    using (SolidBrush brush = new SolidBrush(colors[i]))
                    {
                        g.FillRectangle(brush, x, y, 100, 100);
                    }

                    // Рисуем номер
                    using (Font font = new Font("Arial", 36, FontStyle.Bold))
                    {
                        string number = (i + 1).ToString();
                        SizeF textSize = g.MeasureString(number, font);
                        g.DrawString(number, font, Brushes.White,
                            x + (100 - textSize.Width) / 2,
                            y + (100 - textSize.Height) / 2);
                    }
                }
            }
            return bmp;
        }

        private void ShuffleArray(int[] array)
        {
            Random rng = new Random();
            int n = array.Length;
            while (n > 1)
            {
                n--;
                int k = rng.Next(n + 1);
                int temp = array[k];
                array[k] = array[n];
                array[n] = temp;
            }
        }

        private void UpdatePuzzleDisplay()
        {
            for (int i = 0; i < 9; i++)
            {
                int pieceIndex = currentOrder[i];
                puzzlePieces[i].Image = GetImagePiece(pieceIndex);

                // Подсветка выбранного элемента
                if (i == selectedPieceIndex)
                {
                    puzzlePieces[i].BackColor = Color.Yellow;
                }
                else
                {
                    puzzlePieces[i].BackColor = Color.White;
                }
            }
        }

        private Image GetImagePiece(int index)
        {
            int x = (index % 3) * 100;
            int y = (index / 3) * 100;

            Bitmap piece = new Bitmap(100, 100);
            using (Graphics g = Graphics.FromImage(piece))
            {
                g.DrawImage(originalImage,
                    new Rectangle(0, 0, 100, 100),
                    new Rectangle(x, y, 100, 100),
                    GraphicsUnit.Pixel);
            }
            return piece;
        }

        private void PuzzlePiece_Click(object sender, EventArgs e)
        {
            PictureBox clickedPiece = sender as PictureBox;
            int clickedIndex = (int)clickedPiece.Tag;

            if (selectedPieceIndex == -1)
            {
                // Первый клик - выбираем элемент
                selectedPieceIndex = clickedIndex;
            }
            else
            {
                // Второй клик - меняем местами
                int temp = currentOrder[selectedPieceIndex];
                currentOrder[selectedPieceIndex] = currentOrder[clickedIndex];
                currentOrder[clickedIndex] = temp;

                selectedPieceIndex = -1;
            }

            UpdatePuzzleDisplay();
        }

        public bool IsSolved()
        {
            return correctOrder.SequenceEqual(currentOrder);
        }

        public void Reset()
        {
            ShuffleArray(currentOrder);
            selectedPieceIndex = -1;
            UpdatePuzzleDisplay();
        }

        public void Dispose()
        {
            if (originalImage != null)
            {
                originalImage.Dispose();
            }

            if (puzzlePieces != null)
            {
                foreach (var piece in puzzlePieces)
                {
                    if (piece != null && piece.Image != null)
                    {
                        piece.Image.Dispose();
                    }
                }
            }
        }
    }
}