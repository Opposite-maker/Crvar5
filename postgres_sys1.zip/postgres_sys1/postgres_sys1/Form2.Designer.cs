﻿namespace postgres_sys1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelUserInfo = new System.Windows.Forms.Label();
            this.buttonLogout = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.DataGridViewUsers = new System.Windows.Forms.DataGridView();
            this.DataGridViewRoles = new System.Windows.Forms.DataGridView();
            this.DataGridViewResearcher = new System.Windows.Forms.DataGridView();
            this.DataGridViewSource = new System.Windows.Forms.DataGridView();
            this.DataGridViewResearch = new System.Windows.Forms.DataGridView();
            this.ButtonAddUsers = new System.Windows.Forms.Button();
            this.ButtonDelUsers = new System.Windows.Forms.Button();
            this.ButtonSaveUsers = new System.Windows.Forms.Button();
            this.ButtonAddRoles = new System.Windows.Forms.Button();
            this.ButtonDelRoles = new System.Windows.Forms.Button();
            this.ButtonSaveRoles = new System.Windows.Forms.Button();
            this.ButtonAddResearcher = new System.Windows.Forms.Button();
            this.ButtonDelResearcher = new System.Windows.Forms.Button();
            this.ButtonSaveResearcher = new System.Windows.Forms.Button();
            this.ButtonAddSource = new System.Windows.Forms.Button();
            this.ButtonDelSource = new System.Windows.Forms.Button();
            this.ButtonSaveSource = new System.Windows.Forms.Button();
            this.ButtonAddResearch = new System.Windows.Forms.Button();
            this.ButtonDelResearch = new System.Windows.Forms.Button();
            this.ButtonSaveResearch = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridViewUsers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridViewRoles)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridViewResearcher)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridViewSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridViewResearch)).BeginInit();
            this.SuspendLayout();
            // 
            // labelUserInfo
            // 
            this.labelUserInfo.AutoSize = true;
            this.labelUserInfo.Location = new System.Drawing.Point(12, 21);
            this.labelUserInfo.Name = "labelUserInfo";
            this.labelUserInfo.Size = new System.Drawing.Size(44, 16);
            this.labelUserInfo.TabIndex = 0;
            this.labelUserInfo.Text = "label1";
            // 
            // buttonLogout
            // 
            this.buttonLogout.Location = new System.Drawing.Point(366, 21);
            this.buttonLogout.Name = "buttonLogout";
            this.buttonLogout.Size = new System.Drawing.Size(212, 23);
            this.buttonLogout.TabIndex = 1;
            this.buttonLogout.Text = "Выйти из системы";
            this.buttonLogout.UseVisualStyleBackColor = true;
            this.buttonLogout.Click += new System.EventHandler(this.buttonLogout_Click);
            // 
            // buttonExit
            // 
            this.buttonExit.Location = new System.Drawing.Point(1247, 743);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(204, 23);
            this.buttonExit.TabIndex = 2;
            this.buttonExit.Text = "Закрыть программу";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // DataGridViewUsers
            // 
            this.DataGridViewUsers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridViewUsers.Location = new System.Drawing.Point(15, 94);
            this.DataGridViewUsers.Name = "DataGridViewUsers";
            this.DataGridViewUsers.RowHeadersWidth = 51;
            this.DataGridViewUsers.RowTemplate.Height = 24;
            this.DataGridViewUsers.Size = new System.Drawing.Size(407, 209);
            this.DataGridViewUsers.TabIndex = 3;
            // 
            // DataGridViewRoles
            // 
            this.DataGridViewRoles.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridViewRoles.Location = new System.Drawing.Point(24, 412);
            this.DataGridViewRoles.Name = "DataGridViewRoles";
            this.DataGridViewRoles.RowHeadersWidth = 51;
            this.DataGridViewRoles.RowTemplate.Height = 24;
            this.DataGridViewRoles.Size = new System.Drawing.Size(297, 171);
            this.DataGridViewRoles.TabIndex = 4;
            // 
            // DataGridViewResearcher
            // 
            this.DataGridViewResearcher.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridViewResearcher.Location = new System.Drawing.Point(666, 21);
            this.DataGridViewResearcher.Name = "DataGridViewResearcher";
            this.DataGridViewResearcher.RowHeadersWidth = 51;
            this.DataGridViewResearcher.RowTemplate.Height = 24;
            this.DataGridViewResearcher.Size = new System.Drawing.Size(699, 211);
            this.DataGridViewResearcher.TabIndex = 5;
            // 
            // DataGridViewSource
            // 
            this.DataGridViewSource.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridViewSource.Location = new System.Drawing.Point(666, 266);
            this.DataGridViewSource.Name = "DataGridViewSource";
            this.DataGridViewSource.RowHeadersWidth = 51;
            this.DataGridViewSource.RowTemplate.Height = 24;
            this.DataGridViewSource.Size = new System.Drawing.Size(699, 200);
            this.DataGridViewSource.TabIndex = 6;
            // 
            // DataGridViewResearch
            // 
            this.DataGridViewResearch.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridViewResearch.Location = new System.Drawing.Point(666, 499);
            this.DataGridViewResearch.Name = "DataGridViewResearch";
            this.DataGridViewResearch.RowHeadersWidth = 51;
            this.DataGridViewResearch.RowTemplate.Height = 24;
            this.DataGridViewResearch.Size = new System.Drawing.Size(699, 204);
            this.DataGridViewResearch.TabIndex = 7;
            // 
            // ButtonAddUsers
            // 
            this.ButtonAddUsers.Location = new System.Drawing.Point(427, 103);
            this.ButtonAddUsers.Name = "ButtonAddUsers";
            this.ButtonAddUsers.Size = new System.Drawing.Size(110, 23);
            this.ButtonAddUsers.TabIndex = 8;
            this.ButtonAddUsers.Text = "+";
            this.ButtonAddUsers.UseVisualStyleBackColor = true;
            // 
            // ButtonDelUsers
            // 
            this.ButtonDelUsers.Location = new System.Drawing.Point(427, 187);
            this.ButtonDelUsers.Name = "ButtonDelUsers";
            this.ButtonDelUsers.Size = new System.Drawing.Size(111, 25);
            this.ButtonDelUsers.TabIndex = 9;
            this.ButtonDelUsers.Text = "-";
            this.ButtonDelUsers.UseVisualStyleBackColor = true;
            // 
            // ButtonSaveUsers
            // 
            this.ButtonSaveUsers.Location = new System.Drawing.Point(426, 266);
            this.ButtonSaveUsers.Name = "ButtonSaveUsers";
            this.ButtonSaveUsers.Size = new System.Drawing.Size(111, 28);
            this.ButtonSaveUsers.TabIndex = 10;
            this.ButtonSaveUsers.Text = "Сохранить";
            this.ButtonSaveUsers.UseVisualStyleBackColor = true;
            // 
            // ButtonAddRoles
            // 
            this.ButtonAddRoles.Location = new System.Drawing.Point(327, 422);
            this.ButtonAddRoles.Name = "ButtonAddRoles";
            this.ButtonAddRoles.Size = new System.Drawing.Size(106, 25);
            this.ButtonAddRoles.TabIndex = 11;
            this.ButtonAddRoles.Text = "+";
            this.ButtonAddRoles.UseVisualStyleBackColor = true;
            // 
            // ButtonDelRoles
            // 
            this.ButtonDelRoles.Location = new System.Drawing.Point(327, 483);
            this.ButtonDelRoles.Name = "ButtonDelRoles";
            this.ButtonDelRoles.Size = new System.Drawing.Size(106, 28);
            this.ButtonDelRoles.TabIndex = 12;
            this.ButtonDelRoles.Text = "-";
            this.ButtonDelRoles.UseVisualStyleBackColor = true;
            // 
            // ButtonSaveRoles
            // 
            this.ButtonSaveRoles.Location = new System.Drawing.Point(327, 543);
            this.ButtonSaveRoles.Name = "ButtonSaveRoles";
            this.ButtonSaveRoles.Size = new System.Drawing.Size(106, 31);
            this.ButtonSaveRoles.TabIndex = 13;
            this.ButtonSaveRoles.Text = "Сохранить";
            this.ButtonSaveRoles.UseVisualStyleBackColor = true;
            // 
            // ButtonAddResearcher
            // 
            this.ButtonAddResearcher.Location = new System.Drawing.Point(1371, 33);
            this.ButtonAddResearcher.Name = "ButtonAddResearcher";
            this.ButtonAddResearcher.Size = new System.Drawing.Size(107, 23);
            this.ButtonAddResearcher.TabIndex = 14;
            this.ButtonAddResearcher.Text = "+";
            this.ButtonAddResearcher.UseVisualStyleBackColor = true;
            // 
            // ButtonDelResearcher
            // 
            this.ButtonDelResearcher.Location = new System.Drawing.Point(1371, 112);
            this.ButtonDelResearcher.Name = "ButtonDelResearcher";
            this.ButtonDelResearcher.Size = new System.Drawing.Size(107, 23);
            this.ButtonDelResearcher.TabIndex = 15;
            this.ButtonDelResearcher.Text = "-";
            this.ButtonDelResearcher.UseVisualStyleBackColor = true;
            // 
            // ButtonSaveResearcher
            // 
            this.ButtonSaveResearcher.Location = new System.Drawing.Point(1371, 199);
            this.ButtonSaveResearcher.Name = "ButtonSaveResearcher";
            this.ButtonSaveResearcher.Size = new System.Drawing.Size(107, 23);
            this.ButtonSaveResearcher.TabIndex = 16;
            this.ButtonSaveResearcher.Text = "Сохранить";
            this.ButtonSaveResearcher.UseVisualStyleBackColor = true;
            // 
            // ButtonAddSource
            // 
            this.ButtonAddSource.Location = new System.Drawing.Point(1371, 275);
            this.ButtonAddSource.Name = "ButtonAddSource";
            this.ButtonAddSource.Size = new System.Drawing.Size(107, 24);
            this.ButtonAddSource.TabIndex = 17;
            this.ButtonAddSource.Text = "+";
            this.ButtonAddSource.UseVisualStyleBackColor = true;
            // 
            // ButtonDelSource
            // 
            this.ButtonDelSource.Location = new System.Drawing.Point(1371, 360);
            this.ButtonDelSource.Name = "ButtonDelSource";
            this.ButtonDelSource.Size = new System.Drawing.Size(107, 23);
            this.ButtonDelSource.TabIndex = 18;
            this.ButtonDelSource.Text = "-";
            this.ButtonDelSource.UseVisualStyleBackColor = true;
            // 
            // ButtonSaveSource
            // 
            this.ButtonSaveSource.Location = new System.Drawing.Point(1371, 443);
            this.ButtonSaveSource.Name = "ButtonSaveSource";
            this.ButtonSaveSource.Size = new System.Drawing.Size(107, 23);
            this.ButtonSaveSource.TabIndex = 19;
            this.ButtonSaveSource.Text = "Сохранить";
            this.ButtonSaveSource.UseVisualStyleBackColor = true;
            // 
            // ButtonAddResearch
            // 
            this.ButtonAddResearch.Location = new System.Drawing.Point(1371, 508);
            this.ButtonAddResearch.Name = "ButtonAddResearch";
            this.ButtonAddResearch.Size = new System.Drawing.Size(107, 23);
            this.ButtonAddResearch.TabIndex = 20;
            this.ButtonAddResearch.Text = "+";
            this.ButtonAddResearch.UseVisualStyleBackColor = true;
            // 
            // ButtonDelResearch
            // 
            this.ButtonDelResearch.Location = new System.Drawing.Point(1371, 592);
            this.ButtonDelResearch.Name = "ButtonDelResearch";
            this.ButtonDelResearch.Size = new System.Drawing.Size(107, 23);
            this.ButtonDelResearch.TabIndex = 21;
            this.ButtonDelResearch.Text = "-";
            this.ButtonDelResearch.UseVisualStyleBackColor = true;
            // 
            // ButtonSaveResearch
            // 
            this.ButtonSaveResearch.Location = new System.Drawing.Point(1371, 666);
            this.ButtonSaveResearch.Name = "ButtonSaveResearch";
            this.ButtonSaveResearch.Size = new System.Drawing.Size(107, 23);
            this.ButtonSaveResearch.TabIndex = 22;
            this.ButtonSaveResearch.Text = "Сохранить";
            this.ButtonSaveResearch.UseVisualStyleBackColor = true;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1501, 786);
            this.Controls.Add(this.ButtonSaveResearch);
            this.Controls.Add(this.ButtonDelResearch);
            this.Controls.Add(this.ButtonAddResearch);
            this.Controls.Add(this.ButtonSaveSource);
            this.Controls.Add(this.ButtonDelSource);
            this.Controls.Add(this.ButtonAddSource);
            this.Controls.Add(this.ButtonSaveResearcher);
            this.Controls.Add(this.ButtonDelResearcher);
            this.Controls.Add(this.ButtonAddResearcher);
            this.Controls.Add(this.ButtonSaveRoles);
            this.Controls.Add(this.ButtonDelRoles);
            this.Controls.Add(this.ButtonAddRoles);
            this.Controls.Add(this.ButtonSaveUsers);
            this.Controls.Add(this.ButtonDelUsers);
            this.Controls.Add(this.ButtonAddUsers);
            this.Controls.Add(this.DataGridViewResearch);
            this.Controls.Add(this.DataGridViewSource);
            this.Controls.Add(this.DataGridViewResearcher);
            this.Controls.Add(this.DataGridViewRoles);
            this.Controls.Add(this.DataGridViewUsers);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.buttonLogout);
            this.Controls.Add(this.labelUserInfo);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.DataGridViewUsers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridViewRoles)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridViewResearcher)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridViewSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridViewResearch)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelUserInfo;
        private System.Windows.Forms.Button buttonLogout;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.DataGridView DataGridViewUsers;
        private System.Windows.Forms.DataGridView DataGridViewRoles;
        private System.Windows.Forms.DataGridView DataGridViewResearcher;
        private System.Windows.Forms.DataGridView DataGridViewSource;
        private System.Windows.Forms.DataGridView DataGridViewResearch;
        private System.Windows.Forms.Button ButtonAddUsers;
        private System.Windows.Forms.Button ButtonDelUsers;
        private System.Windows.Forms.Button ButtonSaveUsers;
        private System.Windows.Forms.Button ButtonAddRoles;
        private System.Windows.Forms.Button ButtonDelRoles;
        private System.Windows.Forms.Button ButtonSaveRoles;
        private System.Windows.Forms.Button ButtonAddResearcher;
        private System.Windows.Forms.Button ButtonDelResearcher;
        private System.Windows.Forms.Button ButtonSaveResearcher;
        private System.Windows.Forms.Button ButtonAddSource;
        private System.Windows.Forms.Button ButtonDelSource;
        private System.Windows.Forms.Button ButtonSaveSource;
        private System.Windows.Forms.Button ButtonAddResearch;
        private System.Windows.Forms.Button ButtonDelResearch;
        private System.Windows.Forms.Button ButtonSaveResearch;
    }
}