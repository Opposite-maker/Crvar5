﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql; // Заменяем MySql.Data.MySqlClient на Npgsql

namespace postgres_sys1 // Изменено название пространства имен
{
    public class DatabaseInitializer
    {
        private readonly string _connectionString;

        public DatabaseInitializer(string connectionString)
        {
            _connectionString = connectionString;
        }

        public void InitializeDatabase()
        {
            using (var connection = new NpgsqlConnection(_connectionString))
            {
                connection.Open();

                // Запросы для создания таблиц (изменены для PostgreSQL)
                string createRolesTable = @"
                CREATE TABLE IF NOT EXISTS roles (
                    id SERIAL PRIMARY KEY,
                    name VARCHAR(255) NOT NULL UNIQUE
                );";

                string createUsersTable = @"
                CREATE TABLE IF NOT EXISTS users (
                    id SERIAL PRIMARY KEY,
                    username VARCHAR(255) NOT NULL UNIQUE,
                    password VARCHAR(255) NOT NULL,
                    role_id INT,
                    failed_attempts INT DEFAULT 0,
                    FOREIGN KEY (role_id) REFERENCES roles(id)
                );";

                string createResearcherTable = @"
                CREATE TABLE IF NOT EXISTS researcher (
                    researcher_id SERIAL PRIMARY KEY,
                    surname VARCHAR(255) NOT NULL,
                    name VARCHAR(255) NOT NULL,
                    patronymic VARCHAR(255)
                );";

                string createSourceTable = @"
                CREATE TABLE IF NOT EXISTS source (
                    source_id SERIAL PRIMARY KEY,
                    publication_type VARCHAR(255) DEFAULT 'article',
                    publication_name VARCHAR(255) NOT NULL,
                    output VARCHAR(255)
                );";

                string createResearchTable = @"
                CREATE TABLE IF NOT EXISTS research (
                    research_id SERIAL PRIMARY KEY,
                    description TEXT NOT NULL,
                    researcher_id INT NOT NULL,
                    source_id INT NOT NULL,
                    FOREIGN KEY(researcher_id) REFERENCES researcher(researcher_id),
                    FOREIGN KEY(source_id) REFERENCES source(source_id)
                );";

                ExecuteNonQuery(connection, createRolesTable);
                ExecuteNonQuery(connection, createUsersTable);
                ExecuteNonQuery(connection, createResearcherTable);
                ExecuteNonQuery(connection, createSourceTable);
                ExecuteNonQuery(connection, createResearchTable);

                // Вставка начальных данных в таблицу roles, если она пустая
                string checkRolesDataQuery = "SELECT COUNT(*) FROM roles";
                if (GetTableCount(connection, checkRolesDataQuery) == 0)
                {
                    string insertRolesDataQuery = @"
                    INSERT INTO roles (name) VALUES 
                    ('admin'), ('moderator'), ('user'), ('blocked');";

                    ExecuteNonQuery(connection, insertRolesDataQuery);
                }

                // Вставка начальных данных в таблицы researcher, source и research, если они пустые
                string checkResearcherDataQuery = "SELECT COUNT(*) FROM researcher";
                if (GetTableCount(connection, checkResearcherDataQuery) == 0)
                {
                    string insertResearcherDataQuery = @"
                    INSERT INTO researcher (surname, name, patronymic) VALUES 
                    ('Иванов', 'Иван', 'Иванович'),
                    ('Петров', 'Петр', 'Петрович'),
                    ('Склодовская-Кюри', 'Мария', 'Сидоровна'),
                    ('Козлов', 'Козьма', 'Козьмич'),
                    ('Попов', 'Поп', 'Попович'),
                    ('Лебедева', 'Анна', 'Михайловна');";

                    ExecuteNonQuery(connection, insertResearcherDataQuery);

                    string insertSourceDataQuery = @"
                    INSERT INTO source (publication_type, publication_name, output) VALUES 
                    ('Статья', 'Теория упругости', '2005'),
                    ('Монография', 'Методы оптимизации', '2010'),
                    ('Статья', 'Исследование фазовых переходов', '2008'),
                    ('Статья', 'Квантовая механика в теории информации', '2012'),
                    ('Монография', 'Теория графов', '2007'),
                    ('Статья', 'Математические модели в экономике', '2015');";

                    ExecuteNonQuery(connection, insertSourceDataQuery);

                    string insertResearchDataQuery = @"
                    INSERT INTO research (description, researcher_id, source_id) VALUES 
                    ('Исследование свойств материалов при нагрузке', 1, 1),
                    ('Оптимизация производственных процессов в промышленности', 2, 2),
                    ('Изучение фазовых переходов в металлах при высоких температурах', 3, 3),
                    ('Разработка квантового компьютера на основе теории информации', 4, 4),
                    ('Анализ связности графов в социальных сетях', 5, 5),
                    ('Моделирование экономических процессов в условиях неопределенности', 6, 6);";

                    ExecuteNonQuery(connection, insertResearchDataQuery);
                }
            }
        }

        private void ExecuteNonQuery(NpgsqlConnection connection, string query)
        {
            using (var command = new NpgsqlCommand(query, connection))
            {
                command.ExecuteNonQuery();
            }
        }

        private int GetTableCount(NpgsqlConnection connection, string query)
        {
            using (var command = new NpgsqlCommand(query, connection))
            {
                return Convert.ToInt32(command.ExecuteScalar());
            }
        }
    }
}